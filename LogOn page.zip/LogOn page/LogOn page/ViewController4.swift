//
//  ViewController4.swift
//  LogOn page
//
//  Created by Rahul on 15/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class ViewController4: UIViewController {
    
    @IBOutlet weak var view4: UIView!
    
    
    @IBOutlet weak var RegisterStaff4: UILabel!
    
    
    @IBOutlet weak var Text1: UITextField!
    
    
    @IBOutlet weak var Text2: UITextField!
    
    
    @IBOutlet weak var Text3: UITextField!
    
    
    @IBOutlet weak var Text4: UITextField!
    
    
    @IBOutlet weak var PushLabel: UILabel!
    
    
    @IBOutlet weak var CountryPhnnum4: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Notrecevice(_ sender: Any) {
    }
    
    @IBAction func RegsiterButton4(_ sender: Any) {
    }
    
}
