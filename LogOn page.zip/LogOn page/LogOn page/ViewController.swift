//
//  ViewController.swift
//  LogOn page
//
//  Created by Rahul on 15/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var Logo: UIImageView!
    
    @IBOutlet weak var Orange: UIImageView!
    
    @IBOutlet weak var Car: UIImageView!
    
    @IBOutlet weak var OrangeRideLabel: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    
    @IBAction func LoginButton(_ sender: Any) {
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController2 = storyBoard.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
        self.present(viewController2,animated: true,completion: nil)
        
        
    }

}

