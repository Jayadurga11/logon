//
//  ViewController2.swift
//  LogOn page
//
//  Created by Rahul on 15/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit


class ViewController2: UIViewController {
    
    
    @IBOutlet weak var view1: UIView!
    
    
    @IBOutlet weak var LoginLabel: UILabel!
    
    
    @IBOutlet weak var LoginstaffId: UILabel!
    
    
    @IBOutlet weak var Userlogo: UIImageView!
    
    @IBOutlet weak var Phonenum: UITextField!
    
    
    @IBOutlet weak var Ticklabel: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func showAlert(message: String)
    {
        let alert = UIAlertController(title: "Alert", message:
            message,preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK",
                                     style: .default)
        alert.addAction(okAction)
        self.present(alert, animated: true)
        
    }
    

    @IBAction func LoginButton2(_ sender: Any) {
        
    
        if let StaffId = self.Phonenum.text, StaffId.isEmpty == true{
            showAlert(message: "StaffId cannot be empty")
        }
        else if Phonenum.text?.isValidStaffID == false {
            showAlert(message: "StaffID should be 5 digit")
            
            
        }
        else{
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController3 = storyBoard.instantiateViewController(withIdentifier: "ViewController3") as! ViewController3
        self.present(viewController3,animated: true,completion: nil)
        }
    }
}
extension String {
    var isValidStaffID: Bool {
      //Declaring the rule of characters to be used. Applying rule to current state. Verifying the result.
            let regex = "^[1-9][0-9]{4}$"
        let test = NSPredicate(format: "SELF MATCHES %@", regex)
        let result = test.evaluate(with: self)
        return result
        
            }
    
    var isValidPhoneNumber: Bool {
    //Declaring the rule of characters to be used. Applying rule to current state. Verifying the result.
          let regex = "^[6-9][0-9]{9}$"
      let test = NSPredicate(format: "SELF MATCHES %@", regex)
      let result = test.evaluate(with: self)
      return result
      
          }
    
}
