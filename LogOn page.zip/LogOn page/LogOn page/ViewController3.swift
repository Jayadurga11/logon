//
//  ViewController3.swift
//  LogOn page
//
//  Created by Rahul on 15/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {
    
    
    @IBOutlet weak var Registerstaff: UILabel!
    
    
    @IBOutlet weak var Countrycode: UILabel!
    
    
    @IBOutlet weak var Dropdown: UIImageView!
    
    
    @IBOutlet weak var PhonenumTextfeild: UITextField!
    
    @IBOutlet weak var Regsiterlabel: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
     func showAlert(message: String)
       {
           let alert = UIAlertController(title: "Alert", message:
               message,preferredStyle: .alert)
           let okAction = UIAlertAction(title: "OK",
                                        style: .default)
           alert.addAction(okAction)
           self.present(alert, animated: true)
           
       }
      
    @IBAction func RegisterButton3(_ sender: Any) {
        
        if let PhoneNumber = self.PhonenumTextfeild.text, PhoneNumber.isEmpty == true{
            showAlert(message: "PhoneNumber cannot be empty")
        }
        else if PhonenumTextfeild.text?.isValidPhoneNumber == false {
            showAlert(message: "PhoneNumber should be 10 digit long")
            
            
        }
        else{
        
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController4 = storyBoard.instantiateViewController(withIdentifier: "ViewController4") as! ViewController4
        self.present(viewController4,animated: true,completion: nil)
        }
    }

}
